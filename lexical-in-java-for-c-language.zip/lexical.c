#include<stdio.h>
int main ()
{
    int x = 10;
    int y = 30;
    char t ;
    x1 = x1 + x2 ;

    printf("The sum  is");
    printf(" %d\n", x1 );
    printf("press enter to continue");
    t = getchar();
return 0;
}